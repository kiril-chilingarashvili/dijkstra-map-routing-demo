USE [Routing]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[GetFastestRoute]
	@FLat varchar(20), 
	@FLon varchar(20), 
	@TLat varchar(20), 
	@TLon varchar(20)
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO dbo.RequestHistory (StartLat, StartLon, EndLat, EndLon)
	VALUES (@FLat, @FLon, @TLat, @TLon)

	DECLARE 
		@s int,
		@e int

		SET @s = dbo.GetClosestVertex('POINT(' + @FLon + ' ' + @FLat + ')')
		SET @e = dbo.GetClosestVertex('POINT(' + @TLon + ' ' + @TLat + ')')
	
	IF @s IS NULL OR @s = 0 OR @e IS NULl OR @e = 0
	RETURN

	DECLARE GeomCursor CURSOR FAST_FORWARD FOR

	SELECT 
		r.geom,
		d.IsReverse,
		r.km
	FROM
		dbo.GetShortestPathForStatement('
			SELECT 
				id as EdgeID,
				[source] as SourceVertexID,
				[target] as TargetVertexID,
				cost as Cost,
				reverse_cost as ReverseCost
			FROM dbo.Routes',
			@s,
			@e) d
	INNER JOIN
		dbo.Routes r
		ON d.EdgeID = r.id
	ORDER BY d.Num

CREATE TABLE #tbl (segment int, num int, km real, part_km real, x real, y real)

INSERT INTO #tbl (segment, num, km, part_km, x, y) VALUES (1, 1, 0, 0, @FLon, @FLat)

OPEN GeomCursor;
DECLARE 
	@reverse bit,
	@km real,
	@geom geometry,
	@prev_geom geometry,
	@loop int,
	@i int,
	@count int,
	@point geometry,
	@segment int,
	@num int,
	@km_total real,
	@part_km real

SET @km_total = 0
SET @segment = 1
SET @num = 1

FETCH NEXT FROM GeomCursor INTO @geom, @reverse, @km;
WHILE @@FETCH_STATUS = 0
    BEGIN
		SET @segment = @segment + 1

		SET @km = 0
			
		SET @loop = @geom.STNumPoints()
		SET @count = @loop

		WHILE @loop > 0
		BEGIN
			IF @reverse = 1
				SET @i = @loop
			ELSE
				SET @i = @count - @loop + 1
			SET @point = @geom.STPointN(@i)
			
			IF @num = 1
				SET @km_total = [dbo].[fnGetDistance] (@point.STX, @point.STY,
						@FLon, @FLat, 'Kilometers')
			SET @num = @num + 1
			IF @prev_geom IS NULL
				SET @part_km = 0
			ELSE
				SET @part_km = [dbo].[fnGetDistance] (@point.STX, @point.STY,
					@prev_geom.STX, @prev_geom.STY, 'Kilometers')
			SET @km = @km + @part_km
			Print @point.STSrid
			INSERT INTO #tbl (segment, num, km, part_km, x, y) VALUES(@segment, @num, @km_total + @km, @part_km, @point.STX, @point.STY)
			SET @loop = @loop - 1
			SET @prev_geom =  @point
		END
        
		SET @km_total = @km_total + @km

        FETCH NEXT FROM GeomCursor INTO @geom, @reverse, @km;
    END;
CLOSE GeomCursor;
DEALLOCATE GeomCursor;

SET @part_km  = 0
IF @prev_geom IS NOT NULL
	SET @part_km = [dbo].[fnGetDistance] (@prev_geom.STX, @prev_geom.STY,
			@TLon, @TLat, 'Kilometers')
SET @km_total = @km_total + @part_km

INSERT INTO #tbl (segment, num, km, part_km, x, y) VALUES (@segment + 1, @num + 1, @km_total, @part_km, @TLon, @TLat)

SELECT x, y, segment, num, km, part_km FROM #tbl

DROP TABLE #tbl	
		
END


GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Batch submitted through debugger: script.sql|138|0|C:\Users\kirch\Documents\script.sql

CREATE PROCEDURE [dbo].[SelectClosestVertex]
(
	@Point geometry
)
AS
BEGIN
	SELECT dbo.GetClosestVertex(@Point) as Result
END




GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Batch submitted through debugger: script.sql|156|0|C:\Users\kirch\Documents\script.sql
Create Function [dbo].[fnGetDistance] 
( 
      @Lat1 Float(18),  
      @Long1 Float(18), 
      @Lat2 Float(18), 
      @Long2 Float(18), 
      @ReturnType VarChar(10) 
)
Returns Float(18)
AS
Begin
      Declare @R Float(8); 
      Declare @dLat Float(18); 
      Declare @dLon Float(18); 
      Declare @a Float(18); 
      Declare @c Float(18); 
      Declare @d Float(18);
      Set @R =  
            Case @ReturnType  
            When 'Miles' Then 3956.55  
            When 'Kilometers' Then 6367.45 
            When 'Feet' Then 20890584 
            When 'Meters' Then 6367450 
            Else 20890584 -- Default feet (Garmin rel elev) 
            End
      Set @dLat = Radians(@lat2 - @lat1);
      Set @dLon = Radians(@long2 - @long1);
      Set @a = Sin(@dLat / 2)  
                 * Sin(@dLat / 2)  
                 + Cos(Radians(@lat1)) 
                 * Cos(Radians(@lat2))  
                 * Sin(@dLon / 2)  
                 * Sin(@dLon / 2); 
      Set @c = 2 * Asin(Min(Sqrt(@a))); 

      Set @d = @R * @c; 
      Return @d; 

End

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- Batch submitted through debugger: script.sql|201|0|C:\Users\kirch\Documents\script.sql


CREATE FUNCTION [dbo].[GetClosestVertex]
(
	@Point geometry
)
RETURNS int
AS
BEGIN
	--DECLARE @Point geometry SET @Point = 'POINT (45.0192415 41.7845037)'
	SET @Point.STSrid = 4326

	DECLARE @Result int
	DECLARE @Distance real

	SET @Distance = 0.005

	DECLARE @X float, @Y float

	SET @X = @Point.STX
	SET @Y = @Point.STY

	--DECLARE 
	--	@X1 float, @Y1 float,
	--	@X2 float, @Y2 float,
	--	@X3 float, @Y3 float,
	--	@X4 float, @Y4 float,
	--	@XY1 varchar(100), @XY2 varchar(100),
	--	@XY3 varchar(100), @XY4 varchar(100)

	--SET @X1 = @X - @Distance
	--SET @X2 = @X
	--SET @X3 = @X + @Distance
	--SET @X4 = @X

	--SET @Y1 = @Y
	--SET @Y2 = @Y + @Distance
	--SET @Y3 = @Y
	--SET @Y4 = @Y - @Distance

	--SET @XY1 = CAST(@X1 as varchar(50)) + ' ' + CAST(@Y1 as varchar(50))
	--SET @XY2 = CAST(@X2 as varchar(50)) + ' ' + CAST(@Y2 as varchar(50))
	--SET @XY3 = CAST(@X3 as varchar(50)) + ' ' + CAST(@Y3 as varchar(50))
	--SET @XY4 = CAST(@X4 as varchar(50)) + ' ' + CAST(@Y4 as varchar(50))

 
	--DECLARE @SearchArea geometry = 
	--	geometry::Parse('CIRCULARSTRING(' + @XY1 + ', ' + @XY2 + ', ' + @XY3 + ', ' + @XY4 + ', ' + @XY1 + ')');
	--SET @SearchArea.STSrid = 4326

	SELECT top 1
		@Result = R.[source] 
	FROM
		dbo.Routes R
	WHERE
		@Point.STDistance(R.geom) < @Distance
	ORDER BY
		@Point.STDistance(R.geom)

	--DECLARE @tbl table (geom geometry)
	--INSERT INTO @tbl SELECT @SearchArea
	--INSERT INTO @tbl SELECT Point FROM dbo.Vertex where ID = @Result
	--SELECT * from @tbl

	RETURN @Result
END





GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[RequestHistory](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[StartLat] [varchar](20) NULL,
	[StartLon] [varchar](20) NULL,
	[EndLat] [varchar](20) NULL,
	[EndLon] [varchar](20) NULL,
	[DateCreated] [datetime] NULL,
 CONSTRAINT [PK_RequestHistory] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 2) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING ON
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Routes](
	[id] [int] NOT NULL,
	[osm_id] [bigint] NULL,
	[osm_name] [nvarchar](255) NULL,
	[osm_meta] [nvarchar](255) NULL,
	[clazz] [real] NULL,
	[osm_source_id] [bigint] NULL,
	[osm_target_id] [bigint] NULL,
	[flags] [real] NULL,
	[km] [real] NULL,
	[source] [int] NULL,
	[target] [int] NULL,
	[kmh] [real] NULL,
	[cost] [real] NULL,
	[reverse_cost] [real] NULL,
	[x1] [real] NULL,
	[y1] [real] NULL,
	[x2] [real] NULL,
	[y2] [real] NULL,
	[geom] [geometry] NULL,
 CONSTRAINT [PK_Routes] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 2) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
SET IDENTITY_INSERT [dbo].[RequestHistory] ON 

